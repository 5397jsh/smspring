package edu.sm.app.dto;

public class Search {
}
